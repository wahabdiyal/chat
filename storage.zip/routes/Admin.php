<?php



Route::get('/main', function() {
    return view('admin.index');
});